
int ff()
{

int x=0 & 0;
int u=x | x;
int y=u^~x;


 return y;
}
