struct x { int f;



    };

