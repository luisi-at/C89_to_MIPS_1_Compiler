float x=.44;
