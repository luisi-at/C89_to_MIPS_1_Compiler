int x=-1000;
