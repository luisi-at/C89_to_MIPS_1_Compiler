int x=0;
