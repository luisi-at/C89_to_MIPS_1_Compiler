const char *x="  X \t   ";
