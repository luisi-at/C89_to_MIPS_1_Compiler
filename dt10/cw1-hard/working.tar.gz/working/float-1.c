float x=0.;
