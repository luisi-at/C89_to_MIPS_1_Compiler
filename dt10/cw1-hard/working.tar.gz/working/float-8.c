float x=.44e-10;
