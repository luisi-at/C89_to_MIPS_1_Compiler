const char *x= "  X \" \"  " ;
