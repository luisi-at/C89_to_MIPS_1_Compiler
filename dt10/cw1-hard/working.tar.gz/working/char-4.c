int x=' ';
