int x='x';
